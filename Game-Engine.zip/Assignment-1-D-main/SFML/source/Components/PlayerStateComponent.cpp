#include "../../include/components/PlayerStateComponent.h"
#include "../../include/entities/Player.h"
#include "../../include/core/Game.h"

PlayerStateComponent::PlayerStateComponent() {

}

void PlayerStateComponent::update(Entity* entity, Game* game, float elapsed) {
    
}
